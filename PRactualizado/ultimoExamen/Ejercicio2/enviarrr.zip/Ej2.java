import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Ej2 {
    static Scanner sc = new Scanner(System.in);
    public static int menu(){
        
        System.out.println("1. Mostrar Examen\n" + //
                        "2. Poner Notas\n" + //
                        "3. Salir");
        return (Integer.valueOf(sc.nextLine()));
    }
    //cargar alumnos
    public static ArrayList<Alumno> cargaAlumnos(){
        ArrayList<Alumno> lista = new ArrayList<>();
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examenes","root","toor");
            Statement st = con.createStatement();

            String sql = "SELECT * FROM Alumno";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                lista.add(new Alumno(rs.getInt("idAlumno"), rs.getString("nombre")));
            }
            con.close();
            st.close();
        }catch(SQLException e){
            System.out.println("error cargarAgencia en sql");
            System.err.println(e);
        }catch(Exception e){
            System.out.println("error cargarAgencia");
            System.err.println(e);
        }
        return lista;
    }
    //cargar los examenes
    public static ArrayList<Examen> cargaExamenes(){
        ArrayList<Examen> lista = new ArrayList<>();
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examenes","root","toor");
            Statement st = con.createStatement();

            String sql = "SELECT * FROM Examen";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                
                Examen e = new Examen(rs.getInt("idExamen"), rs.getString("titulo"));
                //
                for (Pregunta pregun : listaPreguntas) {
                    if (pregun.getIdExamen() == e.getIdExamen()) {
                        e.listaP.add(pregun);
                    }
                }
                
                lista.add(e);
            }
            con.close();
            st.close();

        }catch(SQLException e){
            System.out.println("error cargarExamen en sql");
            System.err.println(e);
        }catch(Exception e){
            System.out.println("error cargarExamen");
            System.err.println(e);
        }
        return lista;
    }
    //cargar preguntas
    public static ArrayList<Pregunta> cargaPregunta(){
        ArrayList<Pregunta> lista = new ArrayList<>();
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examenes","root","toor");
            Statement st = con.createStatement();

            String sql = "SELECT * FROM Pregunta;";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
               lista.add(new Pregunta(rs.getInt("nPregunta"), rs.getInt("idExamen"), rs.getString("nomPregunta")));
            }
            con.close();
            st.close();
        }catch(SQLException e){
            System.out.println("error cargaPregunta en sql");
            System.err.println(e);
        }catch(Exception e){
            System.out.println("error cargaPregunta");
            System.err.println(e);
        }
        return lista;
    }
    //opcion 1
    public static void mostra(){
        for (Examen examm : listaExamens) {
                System.out.println(examm);
            }
            System.out.println("Dime el id del examen:");
        int iddd = Integer.valueOf(sc.nextLine());
        System.out.println(listaExamens.get(iddd-1).getTitulo());

        for (Examen exa : listaExamens) {
            if (exa.getIdExamen() == iddd) {
                exa.imprimirLista();
            }
        }
    }
    //opcion 2
    public static void poner(){

        for (Examen examm : listaExamens) {
            System.out.println(examm);
        }
        System.out.println("Dime el id del examen:");
        Integer idddExa = Integer.valueOf(sc.nextLine());
      
        for (Alumno alumno : listaAlumnos) {
            System.out.println(alumno);
        }
        System.out.println("Dime el id del alumno:");
        int idalu = Integer.valueOf(sc.nextLine());
        
        System.out.println("Dime la nota del alumno:");
        Double notaA = sc.nextDouble(); sc.nextLine();

        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examenes","root","toor");
            
            String sql = "INSERT INTO Nota VALUES (?,?,?);";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idalu);
            ps.setInt(2, idddExa);
            ps.setDouble(3, notaA);
            
            int filas= ps.executeUpdate();


            if (filas >0) {
                System.out.println("Datos insertados correctamente");
                
            }else{
                System.out.println("error");
            }
            con.close();
            ps.close();
        }catch(SQLException e){
            System.out.println("error poner en sql");
            System.err.println(e);
        }catch(Exception e){
            System.out.println("error poner");
            System.err.println(e);
        }
    }
    //IMPORTANTE EL ORDEN. Primero cargo preguntas y luego examenes porque en examenes hago una busqueda
    //en la lista de preguntas(la lista debe estar ya con todas las preguntas para poder buscar)
    static ArrayList<Pregunta> listaPreguntas = cargaPregunta();
    static ArrayList<Alumno> listaAlumnos = cargaAlumnos();
    static ArrayList<Examen> listaExamens = cargaExamenes();
    
    public static void main(String[] args) {
        
        int cas;
        do {
            cas = menu();
            switch (cas) {
                case 1:
                    mostra();
                    break;
                case 2:
                    poner();
                    break;
                case 3:
                    System.out.println("Bye");
                    break;
                default: break;
            }
        } while (cas !=3);   
    }
}
